package main
import (
	"fmt"
	"net/http"
)

//Função usada pela HandleFunc
func PaginaInicial(w http.ResponseWriter, r *http.Request) {
	//Disponibiliza um arquivo que será carrego no Endereço /
	http.ServeFile(w, r, "./arquivos/index.html")
}

func main() {

	//Define Endereço e Função
	http.HandleFunc("/", PaginaInicial)
	
	//Porta de Acesso a Aplicação
	//nil é um Parâmetro para usar as configuações padrões GO
	fmt.Println("Iniciando Servidor Web. Acesse localhost:8080")
	http.ListenAndServe(":8080", nil)
}	
